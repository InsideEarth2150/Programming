﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EarthTool.Common.Enums
{
  public enum FileType
  {
    WD,
    TEX,
    MSH
  }
}
