﻿namespace EarthTool.Common.Interfaces
{
  public interface ITEXConverter : IConverter
  {
  }
}
