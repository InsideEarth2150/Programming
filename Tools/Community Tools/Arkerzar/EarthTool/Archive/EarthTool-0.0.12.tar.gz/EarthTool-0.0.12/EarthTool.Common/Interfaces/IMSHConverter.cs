﻿namespace EarthTool.Common.Interfaces
{
  public interface IMSHConverter : IConverter
  {
  }
}
