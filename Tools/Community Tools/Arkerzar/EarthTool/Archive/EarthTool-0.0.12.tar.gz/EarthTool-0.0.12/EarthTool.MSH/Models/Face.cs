﻿namespace EarthTool.MSH.Models
{
  public class Face
  {
    public int V1
    {
      get; set;
    }

    public int V2
    {
      get; set;
    }

    public int V3
    {
      get; set;
    }

    public int UNKNOWN
    {
      get; set;
    }
  }
}
