![](https://ci.appveyor.com/api/projects/status/github/Arkezar/EarthTool?svg=true)

# EarthTool
Simple tool for extraction of Earth 2150 data files
Supports WD unpacking, convertion of TEX to PNG and limited support for MSH models.

## MSH converter
Extraction of msh models is experimental and doesn't support animation data.

## Usage
Application requires .NET Runtime 5.0.

Download current release and run `EarthTool.exe --help` for available options.

Or build it yourself.
