﻿namespace MESHConverter
{
  public class Face
  {
    public int V1
    {
      get; init;
    }

    public int V2
    {
      get; init;
    }

    public int V3
    {
      get; init;
    }

    public int UNKNOWN
    {
      get; init;
    }
  }
}
