﻿namespace EarthTool.Common.Enums
{
  public enum FileType
  {
    WD,
    TEX,
    MSH
  }
}
