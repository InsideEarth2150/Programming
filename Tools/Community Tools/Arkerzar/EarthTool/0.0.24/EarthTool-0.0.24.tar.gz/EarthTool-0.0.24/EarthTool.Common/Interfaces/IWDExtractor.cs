﻿namespace EarthTool.Common.Interfaces
{
  public interface IWDExtractor : IExtractor
  {
  }
}
