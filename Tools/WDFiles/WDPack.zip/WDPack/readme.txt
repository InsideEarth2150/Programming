===========
WDPack 0.8b
===========

This program provides a somewhat WinZip like access to the WD files used by the Earth Engine.

Copyright 2004 by CABAlistic for Inside Earth Operations


Please post bug reports and feature requests in our forum:

Inside Earth Europe (deutsch/german speaking)
http://www.insideearth.de

Inside Earth International (english speaking)
http://www.e2160.com

Inside Earth Polska (po polsku/polish speaking)
http://www.insideearth.pl

Inside Earth Russia (russian speaking)
http://www.ru.e2160.com



